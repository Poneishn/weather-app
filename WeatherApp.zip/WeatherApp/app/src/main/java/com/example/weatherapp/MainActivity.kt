package com.example.weatherapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.weatherapp.api.ApiClient
import com.example.weatherapp.api.ForecastService
import com.example.weatherapp.api.WeatherService
import com.example.weatherapp.databinding.ActivityMainBinding
import com.example.weatherapp.models.WeatherResponse
import com.example.weatherapp.utils.SoundManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.squareup.picasso.Picasso
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var soundManager: SoundManager
    private lateinit var weatherService: WeatherService
    private lateinit var forecastService: ForecastService
    private var isBackgroundVisible = true

    // Разрешения
    private val permissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_EXTERNAL_STORAGE
    )
    private val PERMISSION_REQUEST_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initServices()
        setupUI()
        checkPermissions()
        setupGestureDetector()
    }

    private fun initServices() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        soundManager = SoundManager(this)
        weatherService = ApiClient.weatherService
        forecastService = ApiClient.forecastService
    }

    private fun setupUI() {
        // Настройка SeekBar громкости
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        binding.volumeSeekBar.max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        binding.volumeSeekBar.progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        
        binding.volumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Кнопка звука
        binding.btnSound.setOnClickListener {
            soundManager.toggleMute()
            updateSoundButton()
        }
    }

    private fun updateSoundButton() {
        binding.btnSound.setImageResource(
            if (soundManager.isMuted()) R.drawable.ic_volume_off else R.drawable.ic_volume_on
        )
    }

    private fun setupGestureDetector() {
        val gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (abs(velocityY) > abs(velocityX) && velocityY > 1000) {
                    toggleBackgroundVisibility()
                    return true
                }
                return false
            }
        })

        binding.root.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }
    }

    private fun toggleBackgroundVisibility() {
        val animatorSet = AnimatorSet()
        val backgroundAnim = ObjectAnimator.ofFloat(
            binding.weatherBackground, 
            "translationY", 
            if (isBackgroundVisible) -binding.weatherBackground.height.toFloat() else 0f
        )
        
        val cloudAnim = ObjectAnimator.ofFloat(
            binding.cloudsOverlay,
            "alpha",
            if (isBackgroundVisible) 1f else 0f
        )

        animatorSet.playTogether(backgroundAnim, cloudAnim)
        animatorSet.duration = 800
        animatorSet.interpolator = AccelerateInterpolator()
        animatorSet.start()

        isBackgroundVisible = !isBackgroundVisible
    }

    private fun checkPermissions() {
        if (permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            getCurrentLocation()
        } else {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            getCurrentLocation()
        } else {
            Toast.makeText(this, "Разрешения необходимы для работы приложения", Toast.LENGTH_LONG).show()
        }
    }

    private fun getCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                location?.let {
                    loadWeatherData(it.latitude, it.longitude)
                } ?: showError("Не удалось определить местоположение")
            }
        }
    }

    private fun loadWeatherData(lat: Double, lon: Double) {
        lifecycleScope.launch {
            try {
                val weather = withContext(Dispatchers.IO) {
                    weatherService.getWeatherByCoordinates(lat, lon, "ВАШ_API_КЛЮЧ")
                }
                updateUI(weather)
                loadForecast(lat, lon)
            } catch (e: Exception) {
                showError("Ошибка загрузки данных")
            }
        }
    }

    private fun updateUI(weather: WeatherResponse) {
        // Установка фона по погоде
        val backgroundRes = when (weather.weather[0].main) {
            "Clear" -> R.drawable.bg_sunny
            "Rain" -> R.drawable.bg_rainy
            "Clouds" -> R.drawable.bg_cloudy
            else -> R.drawable.bg_default
        }
        binding.weatherBackground.setImageResource(backgroundRes)

        // Обновление основной информации
        binding.tvCity.text = weather.name
        binding.tvTemperature.text = "${weather.main.temp.toInt()}°C"
        binding.tvDescription.text = weather.weather[0].description.capitalize()

        // Загрузка иконки
        Picasso.get().load("https://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png")
            .into(binding.ivWeatherIcon)

        // Воспроизведение звука
        soundManager.playSound(weather.weather[0].main)
        updateSoundButton()
    }

    private fun loadForecast(lat: Double, lon: Double) {
        lifecycleScope.launch {
            try {
                val forecast = withContext(Dispatchers.IO) {
                    forecastService.get5DayForecast(lat, lon, "5b79e21a9a0894d09c32fe130c05f41f")
                }
                showForecast(forecast.list)
            } catch (e: Exception) {
                showError("Ошибка загрузки прогноза")
            }
        }
    }

    private fun showForecast(forecast: List<ForecastDay>) {
        binding.forecastContainer.removeAllViews()
        forecast.forEach { day ->
            val view = layoutInflater.inflate(R.layout.item_forecast, binding.forecastContainer, false)
            
            view.tvDay.text = SimpleDateFormat("EE", Locale.getDefault()).format(Date(day.dt * 1000))
            view.tvTemp.text = "${day.main.temp.toInt()}°C"
            view.tvPop.text = "${(day.pop * 100).toInt()}%"
            
            Picasso.get().load("https://openweathermap.org/img/wn/${day.weather[0].icon}.png")
                .into(view.ivIcon)
            
            binding.forecastContainer.addView(view)
        }
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        soundManager.release()
        super.onDestroy()
    }
}