package com.example.weatherapp.utils

import android.content.Context
import com.example.weatherapp.models.WeatherResponse
import com.google.gson.Gson

class Prefs(context: Context) {
    private val sharedPref = context.getSharedPreferences("weather_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    var lastWeather: WeatherResponse?
        get() = sharedPref.getString("LAST_WEATHER", null)?.let {
            gson.fromJson(it, WeatherResponse::class.java)
        }
        set(value) {
            sharedPref.edit()
                .putString("LAST_WEATHER", gson.toJson(value))
                .apply()
        }

    var lastLocation: Pair<Double, Double>?
        get() = sharedPref.getString("LAST_LOCATION", null)?.split(",")?.let {
            Pair(it[0].toDouble(), it[1].toDouble())
        }
        set(value) {
            sharedPref.edit()
                .putString("LAST_LOCATION", "${value?.first},${value?.second}")
                .apply()
        }
}