package com.example.weatherapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface WeatherDao {
    @Insert
    suspend fun insert(weather: WeatherEntity)

    @Query("SELECT * FROM weather ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLastWeather(): WeatherEntity?

    @Query("DELETE FROM weather WHERE timestamp < :expiryTime")
    suspend fun deleteOldData(expiryTime: Long = System.currentTimeMillis() - 86400000) // 24 часа
}