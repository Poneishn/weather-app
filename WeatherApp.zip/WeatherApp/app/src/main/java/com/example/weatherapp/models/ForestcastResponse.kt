package com.example.weatherapp.models

data class ForecastResponse(
    val list: List<ForecastDay>
)

data class ForecastDay(
    val dt: Long,
    val main: MainData,
    val weather: List<Weather>,
    val pop: Double, // Вероятность дождя 0..1
    val dt_txt: String
)