package com.example.weatherapp.models

data class WeatherResponse(
    val name: String,          // Название города
    val main: MainData,        // Температура, давление и т.д.
    val weather: List<Weather> // Описание погоды и иконка
)

data class MainData(
    val temp: Double,      // Температура
    val feels_like: Double,// Ощущается как
    val pressure: Int,     // Давление (hPa)
    val humidity: Int      // Влажность (%)
)

data class Weather(
    val id: Int,          // Код погоды (например, 800 — ясно)
    val main: String,     // Группа (Rain, Snow, Clouds и т.д.)
    val description: String, // Детальное описание
    val icon: String      // Идентификатор иконки (например, "01d")
)