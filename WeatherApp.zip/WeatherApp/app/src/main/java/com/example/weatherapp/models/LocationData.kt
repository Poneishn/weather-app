package com.example.weatherapp.models

data class LocationData(
    val latitude: Double,
    val longitude: Double,
    val city: String? = null  // Опционально: название города
)