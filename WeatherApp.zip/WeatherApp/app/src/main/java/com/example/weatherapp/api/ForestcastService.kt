package com.example.weatherapp.api

import com.example.weatherapp.models.ForecastResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface ForecastService {
    @GET("forecast")
    suspend fun get5DayForecast(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric",
        @Query("cnt") days: Int = 5
    ): ForecastResponse
}