package com.example.weatherapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = "weather")
data class WeatherEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val city: String,
    val temp: Double,
    val description: String,
    val icon: String,
    val timestamp: Long = System.currentTimeMillis(),
    val lat: Double,
    val lon: Double
)