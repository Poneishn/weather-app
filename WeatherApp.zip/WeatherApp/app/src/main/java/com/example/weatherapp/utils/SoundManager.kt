class SoundManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var isMuted = false

    fun playSound(weatherType: String) {
        if (isMuted) return
        
        val soundRes = when (weatherType) {
            "Clear" -> R.raw.weather_birds
            "Rain" -> R.raw.weather_rain
            "Clouds" -> R.raw.weather_wind
            else -> null
        }

        soundRes?.let {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer.create(context, it).apply {
                isLooping = true
                start()
            }
        }
    }

    fun toggleMute() {
        isMuted = !isMuted
        if (isMuted) {
            mediaPlayer?.pause()
        } else {
            mediaPlayer?.start()
        }
    }

    fun isMuted() = isMuted

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
    }
}